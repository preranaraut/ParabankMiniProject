package test;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.UserLogin;
import pages.OpenSavingAccount;

public class OpenNewAccountTest extends setup{
    OpenSavingAccount opensavingaccount;
    //Logger log = Logger.getLogger("devpinoyLogger");
    /*saving module:-
     * create saving saving account
     */
    @Test(dataProvider="getdata")
    public void savingAccTest(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
		UserLogin login=new UserLogin(driver);
		login.DoLogin(username,password );
        opensavingaccount=new OpenSavingAccount(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        opensavingaccount.SavingOpenAccount();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //log.debug("account opened succefully");
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test3.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
}
