package test;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.TransactionHistory;
import pages.UserLogin;

public class TransactionHistoryTest extends setup{
      TransactionHistory transactionhistory;
      //Logger log = Logger.getLogger("devpinoyLogger");
      /*Transaction history module:-
       * create saving saving account
       */
    @Test(dataProvider="getdata")
    public void transactionTest(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {  
		UserLogin login=new UserLogin(driver);
		login.DoLogin(username,password );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    	transactionhistory=new TransactionHistory(driver);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        transactionhistory.FindTranaction();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //log.debug("transaction history fetched successfully");
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*Transaction history module:-
     * select account number
     * enter transaction id
     * select date
     * enter date range
     * find by amount
     * click on find transaction
     */
    /*
    /*Transaction history module:-
     * select account number
     * empty transaction id
     * select date
     * enter date range
     * find by amount
     * click on find transction
     */
}
