package test;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.UpdatePhoneNumber;
import pages.UserLogin;

public class UpdatePhoneNumberTest extends setup {
	UpdatePhoneNumber updatePhoneNumber;
	UserLogin login;
    //Logger log = Logger.getLogger("devpinoyLogger");
	  /*update module:-
	   * updating number
	   */
	  @Test(dataProvider="getdata")
	  public void NumberUpdate(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
	      driver.get("https://parabank.parasoft.com/parabank/index.htm");
	      login=new UserLogin(driver);
	      login.DoLogin(username, password);
		  updatePhoneNumber=new UpdatePhoneNumber(driver);
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  String success= updatePhoneNumber.UserPhoneNumberUpdate(phone);
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	        try {
				this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//  log.debug(success);
	  }
	  /*update module:-
	   * updating invalid number
	   */
	  @Test(dataProvider="getdata")
	  public void InvalidNumberUpdateTest(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
	      driver.get("https://parabank.parasoft.com/parabank/index.htm");
	      login=new UserLogin(driver);
	      login.DoLogin(username, password);
		  updatePhoneNumber=new UpdatePhoneNumber(driver);
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	      phone="p";
		  String success= updatePhoneNumber.UserPhoneNumberUpdate(phone);
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	        try {
				this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//  log.debug(success);
	  }
}
