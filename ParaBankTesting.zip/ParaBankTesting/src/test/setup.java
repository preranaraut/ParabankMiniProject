package test;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class setup {
	public WebDriver driver;
	@DataProvider
	public String[][] getdata() {
		String[][] userdata=new String[1][10];
		userdata[0][0]="Prerana";
		userdata[0][1]="Raut";
		userdata[0][8]="prerana";
		userdata[0][2]="jayaram nagar";
		userdata[0][3]="hinjewadi pune";
		userdata[0][4]="maharashtra";
		userdata[0][5]="413622";
		userdata[0][7]="9080";
		userdata[0][6]="9980706950";
		userdata[0][9]="ppp";
		return userdata;
	}
    @BeforeTest
    public void beforeTest(){
        ChromeOptions ops = new ChromeOptions();
        System.setProperty("webdriver.chrome.driver", "src//Resources//driver//chromedriver.exe");
        driver = new ChromeDriver(ops);
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        driver.manage().window().maximize();
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test.png") ;
		      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{
    	//Convert web driver object to TakeScreenshot
    	TakesScreenshot scrShot =((TakesScreenshot)webdriver);
    	//Call getScreenshotAs method to create image file
    	File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
    	//Move image file to new destination
    	File DestFile=new File(fileWithPath);
    	//Copy file at destination
    	FileUtils.copyFile(SrcFile, DestFile);
    	}
	@AfterTest
    public void afterTest(){
     driver.close();
    }
}
