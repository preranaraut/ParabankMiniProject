package test;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.userRegistration;

public class UserRegistrationTest extends setup {
	userRegistration registration;
    //Logger log = Logger.getLogger("devpinoyLogger");
	 /*
     * registration module:-
     * registering valid user
     * 
     */
    @Test(dataProvider="getdata")
    public void UserRegistration(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        registration=new userRegistration(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        registration.DoLogout();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //log.debug(username+"registered");
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test12.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*
     * registration module:-
     * registering already registered user
     */
    @Test(dataProvider="getdata")
    public void UserRegistrationWithAlreadyRegisteredInfo(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //log.debug("registration failed");
        //registration.DoLogout();
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test13.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*
     * registration module:-
     * registering already registered user
     */
    @Test
    public void UserRegistrationWithEmptyCredential() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        registration.doRegistration("","","","","","","","","","");
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test14.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //log.debug("registration failed");
        }
    /*
     * registration module:-
     * registering user with invalid phonenumber
     */
    @Test(dataProvider="getdata")
    public void UserRegistrationWithInvalidPhoneNumber(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        phone="p";
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test14.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
    /*
     * registration module:-
     * registering user with invalid SSN
     */
    @Test(dataProvider="getdata")
    public void UserRegistrationWithInvalidSSN(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        ssn="p";
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test14.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
    /*
     * registration module:-
     * registering user with invalid zipcode
     */
    @Test(dataProvider="getdata")
    public void UserRegistrationWithInvalidZipcode(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        zipcode="p";
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test14.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
    
}
