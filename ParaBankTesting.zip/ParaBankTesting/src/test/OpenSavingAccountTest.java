package test;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.OpenSavingAccount;
import pages.UserLogin;

public class OpenSavingAccountTest extends setup{
	OpenSavingAccount opensavingaccount;
    //Logger log = Logger.getLogger("devpinoyLogger");
    /*saving module:-
     * create saving saving account
     */
    @Test(dataProvider="getdata")
    public void savingAccTest(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
		UserLogin login=new UserLogin(driver);
		login.DoLogin(username,password );
    	opensavingaccount=new OpenSavingAccount(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        opensavingaccount.SavingOpenAccount();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        //log.debug("saving account opened successfully");
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*saving module:-
     * switching saving account to checking account
     */
    @Test(dataProvider="getdata")
    public void SavingAccToCheckingAccTest(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
		UserLogin login=new UserLogin(driver);
		login.DoLogin(username,password );
    	opensavingaccount=new OpenSavingAccount(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        opensavingaccount.SavingOpenAccount();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        opensavingaccount.CheckingAccount();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

}
