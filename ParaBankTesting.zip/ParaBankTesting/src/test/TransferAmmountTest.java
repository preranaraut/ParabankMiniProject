package test;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.UserLogin;
import pages.TransferAmmount;

public class TransferAmmountTest extends setup {
    TransferAmmount transferAmmount;
   // Logger log = Logger.getLogger("devpinoyLogger");
	  /*amount transfer module:-
	   * Transferring fund to another account
	   */	
	  @Test(dataProvider="getdata")
	  public void transferAmount(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException{
		  UserLogin login=new UserLogin(driver);
		  login.DoLogin(username,password );
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  transferAmmount=new TransferAmmount(driver);  
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  transferAmmount.TransferFund();
	      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	        try {
				this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
}
