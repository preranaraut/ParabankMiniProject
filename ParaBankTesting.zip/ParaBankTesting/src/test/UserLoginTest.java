package test;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pages.UserLogin;

public class UserLoginTest extends setup{
	UserLogin login;
    /*
     * login module:-
     * login with valid credentials
     */
    @Test(dataProvider="getdata")
    public void UserLogin(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new UserLogin(driver);
        login.DoLogin(username, password);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        login.log.info("logged in successfully");
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test2.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        login.DoLogout();
    }
    /*
     * login module:-
     * login with invalid credentials
     */
    @Test
    public void InvalidUserLogin() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new UserLogin(driver);
        login.DoLogin("sdet23","sdet@123");
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        login.log.info("logged in failed");
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test1.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //log.debug("error:invalid credential. login failed");
    }
}
