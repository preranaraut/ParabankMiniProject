package test;

import pages.OpenSavingAccount;
import pages.TransactionHistory;
import pages.TransferAmmount;
import pages.UpdatePhoneNumber;
import pages.userRegistration;
import pages.UserLogin;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

public class Integrated_code extends setup {
    userRegistration registration;
    UserLogin login;
    OpenSavingAccount savings;
    TransactionHistory transaction;
    TransferAmmount transferAmmount;
    UpdatePhoneNumber updatePhoneNumber;
    Logger log=LogManager.getLogger(UserLogin.class.getName());
    /*
     * registration module:-
     * registering valid user
     * */
    @Test(priority=1,dataProvider="getdata")
    public void UserRegistration(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        log.info("user has succefully registered");
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test3.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*
     * registration module:-
     * registering already registered user
     * */
    @Test(priority=2,dataProvider="getdata")
    public void ExistingUserRegistration(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new userRegistration(driver);
        registration.doRegistration(firstname,lastName,streetAddress,city,state,zipcode,phone,ssn,username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test4.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
    /*
     * login module:-
     * login with valid credentials
     * */
    @Test(priority=4,dataProvider="getdata")
    public void UserLogin(String firstname,String lastName,String streetAddress, String city,String state,String zipcode,String phone,String ssn,String username,String password) throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new UserLogin(driver);
        login.DoLogin(username,password);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        log.info("user has succefully");
        login.DoLogout();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test5.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*
     * login module:-
     * login with invalid credentials
     * */
    @Test(priority=3)
    public void InvalidUserLogin() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new UserLogin(driver);
        login.DoLogin("sdet23","ppp");
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test6.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*saving module:-
     * creating saving account
     */
    @Test(priority=5)
    public void openSavingAccTest() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        savings=new OpenSavingAccount(driver);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        savings.SavingOpenAccount();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
			this.takeSnapShot(driver, "src//resources//screenshot//test7.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /*transaction History module:-
     * showing transaction history of user
     */
  @Test(priority=6)
  public void transactionHistoryTest() throws InterruptedException {
      transaction=new TransactionHistory(driver);
      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
      transaction.FindTranaction();
      try {
			this.takeSnapShot(driver, "src//resources//screenshot//test8.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
  /*transfer ammount module:-
   * transfer fund to another user
   */
  @Test(priority=7)
  public void transferAmountTest() throws InterruptedException{
	  transferAmmount=new TransferAmmount(driver);  
      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	  transferAmmount.TransferFund();
      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
      try {
			this.takeSnapShot(driver, "src//resources//screenshot//test9.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
  /*update detail module:-
   * updating phone number of user
   */
  @Test(priority=8)
  public void NumberUpdateTest() throws InterruptedException {
	  updatePhoneNumber=new UpdatePhoneNumber(driver);
      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	  String success= updatePhoneNumber.UserPhoneNumberUpdate();
      driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
      try {
			this.takeSnapShot(driver, "src//resources//screenshot//test10.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
}