package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class OpenSavingAccount {
    WebDriver driver;
    @FindBy(xpath = "//a[contains(text(),'Open New Account')]")
    WebElement openNewaccountlink;
    @FindBy(xpath = "//*[@id='type']")
    WebElement newaccount;
    @FindBy(xpath = "//h1[contains(text(),'Account Opened!')]")
    WebElement titile;
    @FindBy(id="type")
    WebElement selectaccount;
    @FindBy(xpath = "//input[@type='submit']")
    WebElement btnSubmit;
    public OpenSavingAccount(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    public void SavingOpenAccount() throws InterruptedException {
        openNewaccountlink.click();
        Select checking=new Select(selectaccount);
        checking.selectByValue("1");
        btnSubmit.click();
        String text=newaccount.getText();
       
    }
  //For the checking account
    public void CheckingAccount() throws InterruptedException {
        openNewaccountlink.click();
        Select checking=new Select(selectaccount);
        checking.selectByValue("0");
        btnSubmit.click();
        String text=newaccount.getText();
       
    }
}