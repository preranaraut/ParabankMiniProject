package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OpenNewAccount {
    WebDriver driver;
    @FindBy(xpath = "//a[contains(text(),'Open New Account')]")
    WebElement openNewaccountlink;
    @FindBy(id="type")
    WebElement selectaccount;
    @FindBy(id="fromAccountId")
    WebElement fromAccount;
    @FindBy(xpath = "//input[@type='submit']")
    WebElement createNewaccountbtn;
    @FindBy(xpath = "//h1[contains(text(),'Account Opened!')]")
    WebElement titile;
    public OpenNewAccount(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    public String CheckingOpenAccount() throws InterruptedException{
        openNewaccountlink.click();
        createNewaccountbtn.click();
        return titile.getText();

    }
}