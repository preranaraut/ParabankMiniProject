package pages;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpdatePhoneNumber {
    WebDriver driver;
    @FindBy(xpath = "//a[contains(text(),'Update Contact Info')]")
    WebElement updateContactlink;
    @FindBy(id="customer.phoneNumber")
    WebElement updateNumber;
    @FindBy(xpath = "//input[@type='submit']")
    WebElement btnUpdate;
    @FindBy(xpath ="//h1[@class='title']")
    WebElement profileUpdate;
    public UpdatePhoneNumber(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    public String UserPhoneNumberUpdate(String phonenumber) throws InterruptedException {
        updateContactlink.click();
        updateNumber.clear();
        updateNumber.sendKeys(phonenumber);
        btnUpdate.click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        return profileUpdate.getText();
    }
}