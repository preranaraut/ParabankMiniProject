package pages;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpdateAddress{
    WebDriver driver;
   @FindBy(xpath = "//a[contains(text(),'Update Contact Info')]")
   WebElement updateAddresslink;
   @FindBy(id="customer.Address")
   WebElement updateAddress;
   @FindBy(xpath = "//input[@type='submit']")
   WebElement btnUpdate;
   @FindBy(xpath ="//h2[@class='title']")
   WebElement profileUpdate;
   @FindBy(id="customer.address.street")
   WebElement address;
   public UpdateAddress(WebDriver driver){
       this.driver = driver;
       PageFactory.initElements(driver,this);
   }   
   public String UserAddressUpdate() throws InterruptedException {
       updateAddresslink.click();
       updateAddress.clear();
       updateAddress.sendKeys("Nagpur");
       btnUpdate.click();
       driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
       return profileUpdate.getText();
   }    

}

