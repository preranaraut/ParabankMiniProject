package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;

public class userRegistration {
    WebDriver driver;
    WebDriverWait wait;
    @FindBy (xpath = "//a[contains(text(),'Register')]")
    WebElement btnRegistration;
    @FindBy(id="customer.firstName")
    WebElement customerFirstname;
    @FindBy(id="customer.lastName")
    WebElement customerLastname;
    @FindBy(id="customer.address.street")
    WebElement customerAddress;
    @FindBy(id="customer.address.city")
    WebElement customerCity;
    @FindBy(id="customer.address.state")
    WebElement customerState;
    @FindBy(id="customer.address.zipCode")
    WebElement zipCode;
    @FindBy(id="customer.phoneNumber")
    WebElement customerPhonenumber;
    @FindBy(id="customer.ssn")
    WebElement customerSsn;
    @FindBy(id="customer.username")
    WebElement customerUsername;
    @FindBy(id="customer.password")
    WebElement Password;
    @FindBy(id="repeatedPassword")
    WebElement confirmPassword;
    @FindBy(xpath = "//input[@type='submit']")
    List<WebElement> btnSubmit;
    @FindBy(xpath = "//a[contains(text(),'Log Out')]")
    WebElement btnLogout;
    public userRegistration(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    public void doRegistration(String firstname,String lastName,String streetAddress,String city,String state,
    		String zipcode,String phone,String ssn, String username,String password)throws InterruptedException {
        btnRegistration.click();
        customerFirstname.sendKeys(firstname);
        customerLastname.sendKeys(lastName);
        customerAddress.sendKeys(streetAddress);
        customerCity.sendKeys(city);
        customerState.sendKeys(state);
        zipCode.sendKeys(zipcode);
        customerPhonenumber.sendKeys(phone);
        customerSsn.sendKeys(ssn);
        customerUsername.sendKeys(username);
        Password.sendKeys(password);
        confirmPassword.sendKeys(password);
        btnSubmit.get(1).click();
    }
    public void DoLogout() {
    	btnLogout.click();
    }
}