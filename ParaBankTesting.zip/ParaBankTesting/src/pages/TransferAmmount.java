package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class TransferAmmount {
    WebDriver driver;
    @FindBy(xpath = "//a[contains(text(),'Transfer Funds')]")
    WebElement transFerbtn;
    @FindBy(id="amount")
    WebElement transferAmount;
    @FindBy(id = "fromAccountId")
    WebElement fromAccount;
    @FindBy(id="toAccountId")
    WebElement toAccount;
    @FindBy(xpath = "//input[@type='submit']")
    WebElement btnTransfer;
    @FindBy(id="newAccountId")
    WebElement newAccountid;

    public TransferAmmount(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    public void TransferFund() throws InterruptedException {
        transFerbtn.click();
        transferAmount.sendKeys("30");
        btnTransfer.click();
    }
    public void TransferFund2() throws InterruptedException {
        transFerbtn.click();
        transferAmount.sendKeys("-10");//It takes any non-zero value hence it is defect
        btnTransfer.click();
    }
     public void TransferFund3() throws InterruptedException {
         transFerbtn.click();
         transferAmount.sendKeys("-0.00");//It takes any non-zero value hence it is defect
         btnTransfer.click();
     }
}