import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class setup {
    public WebDriver driver;
@BeforeTest
    public void beforeTest(){
        ChromeOptions ops = new ChromeOptions();
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\prerana_raut\\Downloads\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver(ops);
        driver.manage().window().maximize();
    }

@AfterTest
    public void afterTest(){
     driver.close();
    }

}