import org.testng.annotations.Test;

import java.io.IOException;

public class ParaBankTest extends setup {
    Registration registration;
    Login login;
    Savings savings;
    Transaction transaction;
    TransferAccount transferAccount;
    UpdatePhoneNumber updatePhoneNumber;

    @Test(priority=1)
    public void UserRegistration() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new Registration(driver);
        registration.doRegistration("SDET","JAVA","jayaram nagar","hinjewadi pune","maharashtra",
            		"413623","9970907090","8907","preerana","sdet@123");
    }
    @Test(priority=2)
    public void UserLogin() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new Login(driver);
        login.DoLogin("preerana","sdet@123");
        Thread.sleep(2000);
        savings=new Savings(driver);
       // Thread.sleep(4000);
        savings.SavingOpenAccount();
    }
  @Test(priority=3)
  public void transactionTest() throws InterruptedException {
//      driver.get("https://parabank.parasoft.com/parabank/index.htm");
//      login=new Login(driver);
//      login.DoLogin("prerana","sdetajava@123");
      Thread.sleep(2000);
      transaction=new Transaction(driver);
      transaction.FindTranaction();
  }
  @Test(priority=3)
  public void transferAmount() throws InterruptedException{
	  transferAccount=new TransferAccount(driver);  
	  transferAccount.TransferFund();
  }
  @Test(priority=4)
  public void NumberUpdate() throws InterruptedException {
	  updatePhoneNumber=new UpdatePhoneNumber(driver);
	  String sucess= updatePhoneNumber.UserPhoneNumberUpdate();
	  Thread.sleep(3000);
  }
}