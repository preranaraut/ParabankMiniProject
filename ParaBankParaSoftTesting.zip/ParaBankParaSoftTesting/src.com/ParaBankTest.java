import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;

public class ParaBankTest {
    Registration registration;
    Login login;
    Savings savings;
    Transaction transaction;
    TransferAmmount transferAmmount;
    UpdatePhoneNumber updatePhoneNumber;
    String firstName="Prerana",
    		lastName="Raut",
    		userName="prerana",
    		streetAddress="jayaram nagar",
    		city="hinjewadi pune",
    		state="maharashtra",
    		ssn="413622",
    		zipcode="9080",
    		phone="9980706950",
    		password="sdet@123";    
    public WebDriver driver;
    @BeforeTest
    public void beforeTest(){
        ChromeOptions ops = new ChromeOptions();
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\prerana_raut\\Downloads\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver(ops);
        driver.manage().window().maximize();
    }
	@AfterTest
    public void afterTest(){
     driver.close();
    }
    /*
     * registration module:-
     * registering valid user
     * */
    @Test(priority=1)
    public void UserRegistration() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new Registration(driver);
        registration.doRegistration(firstName,lastName,streetAddress,city,state,zipcode,phone,ssn,userName,password);
    }
    /*
     * registration module:-
     * registering already registered user
     * */
    @Test(priority=2)
    public void ExistingUserRegistration() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        registration=new Registration(driver);
        registration.doRegistration(firstName,lastName,streetAddress,city,state,zipcode,phone,ssn,userName,password);
    }
    /*
     * login module:-
     * login with valid credentials
     * */
    @Test(priority=3)
    public void UserLogin() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new Login(driver);
        login.DoLogin(userName,password);
        Thread.sleep(2000);
        login.DoLogout();
        Thread.sleep(2000);
    }
    /*
     * login module:-
     * login with invalid credentials
     * */
    @Test(priority=4)
    public void InvalidUserLogin() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new Login(driver);
        login.DoLogin("sdet23",password);
        Thread.sleep(2000);
    }
    /*saving module:-
     * saving account
     */
    @Test(priority=5)
    public void savingAccTest() throws InterruptedException {
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        login=new Login(driver);
        login.DoLogin("sdet23","sdet@123");
        Thread.sleep(2000);
        savings=new Savings(driver);
        savings.SavingOpenAccount();
    }
  @Test(priority=6)
  public void transactionTest() throws InterruptedException {
      driver.get("https://parabank.parasoft.com/parabank/index.htm");
      login=new Login(driver);
      login.DoLogin("prerana","sdetajava@123");
      Thread.sleep(2000);
      transaction=new Transaction(driver);
      transaction.FindTranaction();
  }
  @Test(priority=7)
  public void transferAmount() throws InterruptedException{
	  transferAmmount=new TransferAmmount(driver);  
	  Thread.sleep(2000);
	  transferAmmount.TransferFund();
  }
  @Test(priority=8)
  public void NumberUpdate() throws InterruptedException {
	  updatePhoneNumber=new UpdatePhoneNumber(driver);
	  String success= updatePhoneNumber.UserPhoneNumberUpdate();
	  Thread.sleep(3000);
  }
}