
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class TransferAmmount {
    WebDriver driver;
    @FindBy(xpath = "//a[contains(text(),'Transfer Funds')]")
    WebElement transFerbtn;
    @FindBy(id="amount")
    WebElement transferAmount;
    @FindBy(id = "fromAccountId")
    WebElement fromAccount;
    @FindBy(id="toAccountId")
    WebElement toAccount;
    @FindBy(xpath = "//input[@type='submit']")
    WebElement btnTransfer;
    @FindBy(id="newAccountId")
    WebElement newAccountid;

    public TransferAmmount(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    public void TransferFund() throws InterruptedException {
        transFerbtn.click();
        Thread.sleep(2000);
        transferAmount.sendKeys("30");
        Thread.sleep(1000);
        btnTransfer.click();
        Thread.sleep(3000);
    }
}